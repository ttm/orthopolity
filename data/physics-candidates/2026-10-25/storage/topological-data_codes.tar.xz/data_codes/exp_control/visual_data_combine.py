from scipy import *
import numpy

def importer(dataName):
    Amp1=numpy.load(dataName+"Amp1.npy")
    Amp4=numpy.load(dataName+"Amp4.npy")
    Phi=numpy.load(dataName+"Phi.npy")
    return Amp1,Amp4,Phi

def importer_f(dataName):
    Amp1=numpy.load(dataName+"Amp1_f.npy")
    Amp4=numpy.load(dataName+"Amp4_f.npy")
    Phi=numpy.load(dataName+"Phi_f.npy")
    return Amp1,Amp4,Phi

def imp(dataName):
    Rref=1000
    Amp1,Amp4,Phi=importer(dataName)
    Amp1=array(Amp1);Amp4=array(Amp4);Phi=array(Phi)
    print(Phi)
    Z=Rref*Amp4*(Amp1**2+Amp4**2-2*Amp1*Amp4*cos(Phi))**-0.5
    Alpha=Phi-arctan(-Amp4*sin(Phi)/(Amp1-Amp4*cos(Phi)))
    return Z*(cos(Alpha)+1j*sin(Alpha))

def imp_f(dataName):
    Rref=1000
    Amp1,Amp4,Phi=importer_f(dataName)
    Amp1=array(Amp1);Amp4=array(Amp4);Phi=array(Phi)
    Z=Rref*Amp4*(Amp1**2+Amp4**2-2*Amp1*Amp4*cos(Phi))**-0.5
    Alpha=Phi-arctan(-Amp4*sin(Phi)/(Amp1-Amp4*cos(Phi)))
    imp=Z*(cos(Alpha)+1j*sin(Alpha))
    return imp

def exporter(m,fun):
    files=['g00','g01','g10','g11']
    for dataName in files:
        print(dataName)
        numpy.save('m%d'%m+dataName+fun.__name__, fun(dataName))

def exporter_f(m,fun):
    files=['g1011', 'g1021', 'g1031', 'g1041', 'g1051', 'g1061','g2011', 'g2021', 'g2031', 'g2041', 'g2051', 'g2061', 'g3011','g3021', 'g3031', 'g3041', 'g3051', 'g3061', 'g4011', 'g4021','g4031', 'g4041', 'g4051', 'g4061', 'g5011', 'g5021', 'g5031','g5041', 'g5051', 'g5061', 'g6011', 'g6021', 'g6031', 'g6041','g6051', 'g6061']
    for dataName in files:
        numpy.save('m%d'%m+dataName+fun.__name__, fun(dataName))

m=X
exporter(m,imp)
exporter_f(m,imp_f)




    
