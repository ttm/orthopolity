import pyvisa as visa
from scipy import *
import inspect #for debugging
import time
import numpy
import winsound
import msvcrt

def connect():
    rm=visa.ResourceManager()
    global ins1,ins2
    ins1=rm.get_instrument('USB0::1689::844::C011565::0::INSTR')
    ins2=rm.get_instrument('TCPIP0::169.254.14.217::INSTR',timeout=5)
    print('\nConnected:\n'+ins1.query('*IDN?'))
    print('\nConnected:\n'+ins2.query('*IDN?'))

def initSet(freq_Hz,amp_Vpp):
    ins1.write('*RST')
    ins2.write('*RST')
    ins1.write('OUTP1:STAT ON'); ins1.write('SOUR1:FREQ:CW %d'%freq_Hz); ins1.write('SOUR1:VOLT:LEV:IMM:AMPL %.f'%amp_Vpp)
##    ins1.write('OUTP2:STAT ON'); ins1.write('SOUR2:FREQ:CW %d'%freq_Hz); ins1.write('SOUR2:VOLT:LEV:IMM:AMPL %.f'%amp_Vpp)

    ins2.write('CHAN4:STAT ON')
    ins2.write('CHAN1:SCAL 0.4') # fine tune the scale latter depending on the measured min/max value.
    ins2.write('CHAN4:SCAL 0.4') # fine tune the scale latter depending on the measured min/max value.
    ins2.write('TIM:SCAL 5E-6')
    time.sleep(1)

def StartMeasure():
    ins2.write('MEAS1 ON')
    ins2.write('MEAS1:SOUR C1W1')
    ins2.write('MEAS1:CAT AMPT')
    ins2.write('MEAS1:MAIN AMPL')

    ins2.write('MEAS2 ON')
    ins2.write('MEAS2:SOUR C4W1')
    ins2.write('MEAS2:CAT AMPT')
    ins2.write('MEAS2:MAIN AMPL')


def StartMeasure_f():
    ins2.write('CALC:MATH1:STAT on')
    ins2.write('CALC:MATH1:FFT:FRAM:ARIT AVER')
    ins2.write('CALC:MATH1:EXPR \'FFTmag(Ch1)\n\'')
    ins2.write('CALC:MATH1:FFT:MAGN:SCAL LIN')

    ins2.write('CALC:MATH2:STAT on')
    ins2.write('CALC:MATH2:FFT:FRAM:ARIT AVER')
    ins2.write('CALC:MATH2:EXPR \'FFTmag(Ch4)\n\'')
    ins2.write('CALC:MATH2:FFT:MAGN:SCAL LIN')

    ins2.write('CALC:MATH3:STAT on')
    ins2.write('CALC:MATH3:FFT:FRAM:ARIT AVER')
    ins2.write('CALC:MATH3:EXPR \'FFTphi(Ch1)-FFTphi(Ch4)\n\'')
    ins2.write('CALC:MATH3:FFT:MAGN:SCAL LIN')



def fourier_meas(freq_Hz):
    ins2.write('CALC:MATH1:FFT:CFR %f'%freq_Hz)
    ins2.write('CALC:MATH1:SPAN %f'%(2*freq_Hz))


    ins2.write('CALC:MATH2:FFT:CFR %f'%freq_Hz)
    ins2.write('CALC:MATH2:SPAN %f'%(2*freq_Hz))


    ins2.write('CALC:MATH3:FFT:CFR %f'%freq_Hz)
    ins2.write('CALC:MATH3:SPAN %f'%(2*freq_Hz))

    time.sleep(0.4)

    amp1=ins2.query('CALC:MATH1:DATA?').split(',')
    N=int(len(amp1)/2)
    amp4=ins2.query('CALC:MATH2:DATA?').split(',')
    phi=ins2.query('CALC:MATH3:DATA?').split(',')
    return float(amp1[N]),float(amp4[N]),float(phi[N])/180*pi


def auto_mapping(f):
    note=10000
    for i in range(2,-1,-1):
        winsound.Beep(int(note*2**(-i/2)),50)
    Amp1=[];Amp4=[];Phi=[]
    try:
        while True:
            time.sleep(0.2)
            amp1=float(ins2.query('MEAS1:ARES?'))
            amp4=float(ins2.query('MEAS2:ARES?'))
            da=abs(amp1-amp4)/amp1
            if (da>0.3):
                time.sleep(0.2)
                amp1,amp4,phi=fourier_meas(f)
                winsound.Beep(note,50)
                Amp1+=[amp1];Amp4+=[amp4];Phi+=[phi]
                Z=1000*amp4*(amp1**2+amp4**2-2*amp1*amp4*cos(phi))**-0.5
                Alpha=phi-arctan(-amp4*sin(phi)/(amp1-amp4*cos(phi)))
##                print(Z)
                print(Z*cos(Alpha),Z*sin(Alpha))

                time.sleep(1)
    except KeyboardInterrupt:
        pass
    print(len(Amp1))
    dataName=input("Data name:")
    numpy.save(dataName+"Amp1",Amp1)
    numpy.save(dataName+"Amp4",Amp4)
    numpy.save(dataName+"Phi",Phi)
    for i in range(3):
        winsound.Beep(int(note*2**(-i/3)),50)

def fswp():
    note=10000
    winsound.Beep(int(note*2**(-1/3)),100)
        
    Freq=linspace(77,160,84)*1000

    Amp1=[];Amp4=[];Phi=[]

    for freq in Freq:
        ins1.write('SOUR1:FREQ:CW %d'%freq)
        time.sleep(0.4)
        amp1,amp4,phi=fourier_meas(freq)
        if (freq==158000):
            winsound.Beep(1000,100)

        print("%.2fkHz   %.2fOhm"%(freq/1000,1000*amp4*(amp1**2+amp4**2-2*amp1*amp4*cos(phi))**-0.5))
##        if (freq!=67000) and (freq!=68000)and(freq!=69000):
        Amp1+=[amp1];Amp4+=[amp4];Phi+=[phi]

    
    winsound.Beep(5000,100)
    dataName=siteAutoGen()
    numpy.save(dataName+"Amp1_f",Amp1[3:])
    numpy.save(dataName+"Amp4_f",Amp4[3:])
    numpy.save(dataName+"Phi_f",Phi[3:])
##    print(len(Amp1[3:]))
        

def dataNameListDefault():
    dataNameList=[]
    for i in [1,2,3,4,5,6]:
        for j in [1,2,3,4,5,6]:
            dataNameList+=['g'+str(1000*i+10*j+1)]
    numpy.save("dataNameList",["HEAD"]+dataNameList)
    numpy.save("dataNamePre","HEAD")
    
def siteAutoGen():
    dataNameList=numpy.load('dataNameList.npy')
    dataNamePre=numpy.load('dataNamePre.npy')
    dataNameList=list(dataNameList)
##    print(dataNamePre)
##
##    print(dataNameList)
    dataNameNow=dataNameList[dataNameList.index(dataNamePre)+1]
    siteCon=input("Which site measured?(%s):"%dataNameNow)
    if len(siteCon)!=0:
        dataNameNow=siteCon
    numpy.save('dataNamePre',dataNameNow)
    return dataNameNow


##dataNameListDefault()


f=113000
V=1
connect()
initSet(freq_Hz=f,amp_Vpp=V)
StartMeasure_f()

##fswp()

StartMeasure()
auto_mapping(f)
