from scipy import *
from matplotlib import pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from numpy import linalg as lg
from matplotlib import rcParams as rcP

Nk=1000
Kx=linspace(-pi,pi,Nk)
Ky=linspace(-pi,pi,Nk)
Kz=linspace(-pi,pi,Nk)
Kw=linspace(-pi,pi,Nk)

def energy(J,J1,J2,m,k):
    kx,ky,kz,kw=k
    d1=J*(2*cos(kx)+cos(ky))
    d2=J*sin(ky)
    d3=J*(2*cos(kz)+cos(kw))
    d4=J*sin(kw)
    d5=m+2*J1*cos(2*kx+2*kz)+2*J2*cos(2*kx-2*kz)
    return (d1**2+d2**2+d3**2+d4**2+d5**2)**0.5

def infinite_bandedge(J,J1,J2):
    M=linspace(-10,10,161)
    E=[]
    for m in M:
        X,Z=meshgrid(Kx,Kz)
        Emin=energy(J,J1,J2,m,[X,0,Z,0]).min()
##        print(Emin)
        E+=[Emin]
    plt.plot(M,E)
    plt.ylim([0,10])
    plt.show()
    

def bandplot_xz(J,J1,J2,m):
    rcP.update({'font.size': 23})
    ky=0;kw=0
    fig=plt.figure(figsize=(12,10))
    ax=fig.add_subplot(111,projection='3d')
    X,Z=meshgrid(Kx,Kz)
    E=energy(J,J1,J2,m,[X,ky,Z,kw])
    X=array(X)
    Z=array(Z)
    print(shape(E))
    ax.plot_surface(X,Z,E)
    ax.plot_surface(X,Z,-E)
##    ax.set_xlabel(r"$k_x$")
##    ax.set_zticks([-2,-1,0,1,2])
##    ax.set_ylabel(r"$k_z$")
##    ax.set_zlabel("E")
##    ax.set_zlim([-2,2])
    plt.savefig("3Dm%d_xz.svg"%m)

    plt.show()

def bandplot_yw(J,J1,J2,m):
    rcP.update({'font.size': 23})
    a=2/3*pi
##    a=2
    kx=a;kz=a
    fig=plt.figure(figsize=(12,10))
    ax=fig.add_subplot(111,projection='3d')
    Y,W=meshgrid(Ky,Kw)
    E=energy(J,J1,J2,m,[kx,Y,kz,W])
    ax.plot_surface(Y/pi,W/pi,E)
    ax.plot_surface(Y/pi,W/pi,-E)

    ax.set_xlabel(r"$k_y/\pi$",labelpad=20)
    ax.set_xticks([-1,0,1])
    ax.set_yticks([-1,0,1])
    ax.set_zticks([-2,-1,0,1,2])
    ax.set_ylabel(r"$k_w/\pi$",labelpad=20)
    ax.set_zlabel("E")
    ax.set_zlim([-3,3])
    ax.set_xlim([-1,1])
    ax.set_ylim([-1,1])
    plt.savefig("3Dm%d.svg"%m)
    ax.view_init(20, 30)
    plt.show()

def bandplot_xy(J,J1,J2,m):
    kw=0;kz=0
    fig=plt.figure()
    ax=fig.add_subplot(111,projection='3d')
    X,Y=meshgrid(Kx,Ky)
    E=energy(J,J1,J2,m,[X,Y,kz,kw])
##    X=array(X)
##    Z=array(Z)
##    print(shape(E))
    ax.plot_surface(X,Y,E)
    ax.plot_surface(X,Y,-E)

    ax.set_xlabel("Kx")
    ax.set_ylabel("Ky")
##    plt.show()

J=1;J1=2;J2=-2
m=7

bandplot_yw(J,J1,J2,m)
##for m in [5,6,7]:
##    bandplot_yw(J,J1,J2,m,m-4)
##plt.show()
##infinite_bandedge(J,J1,J2)
