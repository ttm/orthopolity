import numpy
from scipy import *
import subprocess
import matplotlib.pyplot as plt
import commonFuncs as cs
from pylab import *
from mpl_toolkits.mplot3d import Axes3D
from random import uniform

setJp,setJn,setJ1p,setJ1n,setJ2p,setJ2n,setGa,setGb,setGc,setGd,coupNum,Ls=numpy.load('coupling_terms.npy',allow_pickle=True)
Lx,Ly,Lz,Lw=Ls
N=Lx*Ly*Lz*Lw

def coup_gen(C,C1,C2,L,L1,L2):
    coupSet={0:setJp,1:setJn,2:setJ1p,3:setJ1n,4:setJ2p,5:setJ2n,6:setGa,7:setGb,8:setGc,9:setGd}
    coupVal={0:('c0',C*10**9,'n'),1:('l0',L*10**6,'u'),2:('c1',C1*10**9,'n'),3:('l1',L1*10**6,'u'),4:('l2',L2*10**6,'u'),5:('c2',C2*10**9,'n'),6:'Ga',7:'Gb',8:'Gc',9:'Gd'}
    fileTW=open('coup_netlist','w')
    ## coupling terms##
    fileTW.write('* Netlist\n\n')

    n_compo=0
    for i in range(6):
        pairs=coupSet[i]
        compo,val,unit=coupVal[i]
        for pair in pairs:
            nx,ny=pair;nx+=1;ny+=1 ## avoid zero which is fixed to ground
            if nx>ny:
                n_compo+=1
                if i in [1,3,4]:
                    linkR=24.00001
                    fileTW.write('%s%d %d %d %.3f%s\n'%(compo,n_compo,nx,n_compo+5*N,val*uniform(0.9,1.1),unit))
                    fileTW.write('r%d %d %d %.3f\n'%(n_compo,ny,n_compo+5*N,uniform(0.9,1.1)*linkR*val/(L*10**6)))
                else:
                    linkR=10.00001
                    fileTW.write('%s%d %d %d %.3f%s\n'%(compo,n_compo,nx,n_compo+5*N,val*uniform(0.9,1.1),unit))
                    fileTW.write('r%d %d %d %.3f\n'%(n_compo,ny,n_compo+5*N,uniform(0.9,1.1)*linkR))
            else:
                continue
    fileTW.close()

def grou_gen(C,C1,C2,L,L1,L2,L0,Cm):
    with open("coup_netlist",'r') as f:
        with open("grou_netlist", "w") as f1:
            for line in f:
                f1.write(line)
    fileTW=open('grou_netlist','a')
    n_compo=0
    linkR=48.00001
    for i in range(N): 
        coor=cs.n2c(Ls,i)
        sublat,m,n,j,l=cs.c2s(Ls,coor)
        coupnum=coupNum[i]
        coupnum_bulk=array([6,3,2,2,2,2])
        coupnum_surface=coupnum_bulk-coupnum
        CNum=coupnum_surface[0::2]
        LNum=coupnum_surface[1::2]
        if sublat=='c' or sublat=='d':
            groundC=CNum[0]*C+CNum[1]*C1+LNum[2]*C2+Cm
        else:
            groundC=CNum[0]*C+CNum[1]*C1+LNum[2]*C2        
        groundL=1/(LNum[0]/L+LNum[1]/L1+CNum[2]/L2+1/L0)
        fileTW.write('rcg%d %d %d %.3f\n'%(n_compo,i+1,i+1+N,uniform(0.9,1.1)*10.00001))
        fileTW.write('rlg%d %d %d %.3f\n'%(n_compo,i+1,i+1+2*N,uniform(0.9,1.1)*linkR*groundL/L))
        fileTW.write('cg%d %d %d %.5fu\n'%(n_compo,i+1+N,3*N+1,uniform(0.9,1.1)*groundC*10**6))
        n_compo+=1
        fileTW.write('lg%d %d %d %.2fu\n'%(n_compo,i+1+2*N,3*N+1,uniform(0.9,1.1)*groundL*10**6))
    fileTW.close()

def get_netlist(C,C1,C2,L,L1,L2,L0,Cm,nf,freq,K):
    n0=3*N+1
    with open("grou_netlist",'r') as f:
        with open("netlist", "w") as f1:
            for line in f:
                f1.write(line)
    fileTW=open('netlist','a')
    subprocess.run(['rm','Result.data'])
    Rload=50
    fileTW.write('rload%d %d %d %.2f\n'%(K, 3*N+2+K, K, Rload))
    fileTW.write('vin%d %d %d dc 0 ac 1\n'%(K, 3*N+2+K, n0)) ### The source is added between site n0=3N+1 (circuit ground) and 3N+2+K
    fileTW.write('.ac lin %d %.5f %.5f\n'% (nf,freq/120*80,freq/120*160))
    fileTW.write('.control \n')
    fileTW.write('run \n')
    fileTW.write('set appendwrite \n')
    for i in range(N):
##        fileTW.write('wrdata Result  i(rload%d) \n'%(K))
        Rload_0=(Rload if i+1==K else 0) ### only record relative impedance of source connected site
        fileTW.write('wrdata Result  (v(%d)-v(%d))/(v(%d)-v(%d))*%.f \n'%(K, n0,K,3*N+2+K,Rload_0))
    fileTW.write('exit \n')
    fileTW.write('\n.endc \n')
    fileTW.write('.end \n')
    fileTW.close(); 
    subprocess.run(['ngspice', 'netlist'])

def data_parser(nf,K,m):
    file=open('Result.data','r')
    freq=[];wave=[]
    for lines in file:
        line=lines.split(' ');line.pop(-1);line=[float(x) for x in line if x!='']
        freq+=[line[0]]
        realData=line[1]
        imagData=line[2]
        wave+=[realData+1j*imagData]
##    print(wave)
    freq_=[];wave_=[]
    for i in range(nf):
##        print(freq[i])
        freq_+=[freq[i]]
        wave_+=[wave[i::nf]]
    numpy.save('./data/m%d_wave_data_%d.npy'%(10*m,K),wave_)
    numpy.save('./data/m%d_freq_data_%d.npy'%(10*m,K),freq_)

def combined_wave(m,tag):
    Nsource=N
    nf=81
    freqE0=120000
    
    wavesum=zeros([nf,N])*1j    
    sourcelist=[]
    for i in range(N):
        x,y,z,w=cs.n2c(Ls,i)
        if (y==0 and w==1): ##and (x in arange(Lx/2)) and (z in arange(Lz/2)):
            sourcelist+=[i+1]        
    Nsource=len(sourcelist)
    progress=0
    for K in sourcelist:
        print(tag,m,'%d/%d'%(progress,Nsource))
        get_netlist(C,C1,C2,L,L1,L2,L0,Cm,nf,freqE0,K)
        data_parser(nf,K,m)
        freq=numpy.load('./data/m%d_freq_data_%d.npy'%(10*m,K))
        wave=numpy.load('./data/m%d_wave_data_%d.npy'%(10*m,K))
        wavesum+=wave
        progress+=1
    nB=[];nS=[];Ne=N/2;Nen=N/2
    for i in range(N):
        x,y,z,w=cs.n2c(Ls,i)
        if (x in [0,1]) or (x in [Lx-1,Lx-2]) or (z in [0,1]) or (z in [Lz-1,Lz-2]):
            nS+=[i]
        else:
            nB+=[i]
    impB=sum(real((wavesum[:,nB])),axis=1)/len(nB)*4
    impS=sum(real((wavesum[:,nS])),axis=1)/len(nS)*4
    numpy.save('./randomData/m%d_%d.npy'%(m*10,tag),(impB,impS,freq))

def real_param_coup(J,J1,J2,E0,C,L):
    omega=(L*C)**-0.5
    freqE0=omega/2/pi
    C1=J1*C; C2=-J2*C
    L1=L*C/C1; L2=L*C/C2;
    return C,C1,C2,L,L1,L2,freqE0

def real_param(J,J1,J2,m,E0,C,L):
    omega=(L*C)**-0.5
    freqE0=omega/2/pi
    C1=J1*C; C2=-J2*C; Cm=2*m*C
    L1=L*C/C1; L2=L*C/C2;
    L0=L/(3+m-E0) # E0=m+3-L/L0
    approx_impe=1/omega/C, omega*L ## ~(L/C)**0.5~1k
    return C,C1,C2,L,L1,L2,L0,Cm,freqE0

def freq_mode(m):
    impBu,impBd,impSu,impSd,freq=numpy.load('range_m%d.npy'%m)
    plt.plot(freq/1000,abs(impBu),c='dodgerblue')
    plt.plot(freq/1000,abs(impBd),c='dodgerblue')
    plt.plot(freq/1000,abs(impSu),c='pink')
    plt.plot(freq/1000,abs(impSd),c='pink')
##    plt.plot(freq/1000,abs(impB)/((len(nB)*abs(impB)+len(nS)*abs(impS)))*(len(nB)+len(nS)),c='green')
##    plt.ylim([0,2])
##    plt.ylim([0,800])
##    plt.xlim([80,160])
##    plt.show()

def freq_mode_0(m):
    freq=numpy.load('m%d_freq_data_f.npy'%(m*10))
    wave=numpy.load('m%d_wave_data_f.npy'%(m*10))
    nB=[26, 27, 38, 39, 32, 33, 44, 45, 98, 99, 110, 111, 104, 105, 116, 117]
    nSo=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 17, 18, 23, 24, 29, 30, 35, 36, 41, 42, 47, 48, 53, 54, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 89, 90, 95, 96, 101, 102, 107, 108, 113, 114, 119, 120, 125, 126, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143]
    nSi=[13, 14, 15, 16, 19, 20, 21, 22, 25, 28, 31, 34, 37, 40, 43, 46, 49, 50, 51, 52, 55, 56, 57, 58, 85, 86, 87, 88, 91, 92, 93, 94, 97, 100, 103, 106, 109, 112, 115, 118, 121, 122, 123, 124, 127, 128, 129, 130]
    nS=nSo+nSi
    impB=sum(real((wave[:,nB])),axis=1)/len(nB)*4
    impS=sum(real((wave[:,nS])),axis=1)/len(nS)*4
    plt.plot(freq/1000,abs(impB),'--',c='blue')
    plt.plot(freq/1000,abs(impS),c='red')

def range_plot():
    impBu,impSu,freq=numpy.load('./randomData/m0_1.npy')
    impBd,impSd,freq=numpy.load('./randomData/m0_1.npy')
    for m in [0,1,2,3,4,5,6,7,8]:
        for tag in range(1,51):
            impB,impS,freq=numpy.load('./randomData/m%d_%d.npy'%(m*10,tag))
            impBu=array([impBu,impB]);impBu=numpy.max(impBu,axis=0)
            impBd=array([impBd,impB]);impBd=numpy.min(impBd,axis=0)
            impSu=array([impSu,impS]);impSu=numpy.max(impSu,axis=0)
            impSd=array([impSd,impS]);impSd=numpy.min(impSd,axis=0)
        numpy.save('range_m%d.npy'%m,(impBu,impBd,impSu,impSd,freq))
    

## THESE ARE CONSTANCES
J=1;J1=2.0;J2=-2.0;C=1.0e-9;L=2000e-6
E0=0
C,C1,C2,L,L1,L2,freqE0=real_param_coup(J,J1,J2,E0,C,L)

##for tag in range(50,101):
##    coup_gen(C,C1,C2,L,L1,L2)
##    for m10 in [0,10,20,30,40,50,60,70,80]:
##        m=m10/10
##        C,C1,C2,L,L1,L2,L0,Cm,freqE0_=real_param(J,J1,J2,m,E0,C,L)
##        grou_gen(C,C1,C2,L,L1,L2,L0,Cm)
##        combined_wave(m,tag)

range_plot()
plt.figure(figsize=[13,12])
for m in [0,1,2,3,4,5,6,7,8]:
    plt.subplot(3,3,m+1)
    plt.title("m=%d"%m,y=0.9)
    plt.xticks([80,100,120,140,160])
    
    if not m==0:
        plt.yticks([])
    if m==7:
        plt.xlabel("f/kHz")
    freq_mode(m)
    freq_mode_0(m)
plt.savefig("f_LDOS_with_tolerance.svg")
plt.show()

