from scipy import *
### common paras
sublatDict={'a':array([0,0,0,0]),'b':array([1,0,1,0]),'c':array([1,0,0,0]),'d':array([0,0,1,0])}
R1,R2,R3,R4=array([1,-1,0,0]),array([1,1,0,0]),array([0,0,1,-1]),array([0,0,1,1])
### common funcs
def site_gen(Ls):
    Lx,Ly,Lz,Lw=Ls
    siteSet=set()
    for w in range(Lw):
        for z in range(Lz):
            for y in range(Ly):
                for x in range(Lx):
                    siteSet|={(x,y,z,w)} 
    return siteSet

def c2s(Ls,coor):
    for sublat in ['a','b','c','d']:
        coor0=sublatDict[sublat]
        vec=coor-coor0
        m,n,j,l=vec.dot(R1)/2,vec.dot(R2)/2,vec.dot(R3)/2,vec.dot(R4)/2
        def is_int(a):
            return (int(a)-a)==0
        if is_int(m)&is_int(n)&is_int(j)&is_int(l):
            return sublat,m,n,j,l

def s2c(Ls,sublat,m,n,j,l):
    coor=sublatDict[sublat]+m*R1+n*R2+j*R3+l*R4
    return coor

def c2n(Ls,coor): 
    Lx,Ly,Lz,Lw=Ls
    num=coor[0]+coor[1]*Lx+coor[2]*Lx*Ly+coor[3]*Lx*Ly*Lz
    return int(num)

def n2c(Ls,num): 
    Lx,Ly,Lz,Lw=Ls
    w=num//(Lx*Ly*Lz); Rw=num%(Lx*Ly*Lz); z=Rw//(Lx*Ly); Rz=Rw%(Lx*Ly); y=Rz//(Lx); x=Rz%(Lx)
    return array([x,y,z,w])

def n2s(Ls,num):
    return c2s(Ls,n2c(Ls,num))

def s2n(Ls,sublat,m,n,j,l):
    return c2n(Ls,s2c(Ls,sublat,m,n,j,l))
