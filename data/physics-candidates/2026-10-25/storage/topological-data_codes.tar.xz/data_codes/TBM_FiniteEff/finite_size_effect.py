from scipy import *
import commonFuncs as cs
import numpy
import scipy.sparse as sp
from scipy.sparse.linalg import eigsh
import matplotlib.pyplot as plt
import cupy

Nxz=50
Lx,Ly,Lz,Lw=Nxz,2,Nxz,2

N=Lx*Ly*Lz*Lw
Ls=[Lx,Ly,Lz,Lw]
siteSet=cs.site_gen(Ls)

def a_linked_to(Ls,m,n,j,l):
    siteSet=cs.site_gen(Ls)
    Jp=[['c',m,n,j,l],['c',m-1,n,j,l],['d',m,n,j,l],['d',m,n,j-1,l],['c',m-1,n-1,j,l],['d',m,n,j-1,l-1]]
    Jn=[]
    J1p=[['a',m+1,n+1,j+1,l+1],['a',m-1,n-1,j-1,l-1]]
    J1n=[]
    J2p=[['a',m+1,n+1,j-1,l-1],['a',m-1,n-1,j+1,l+1]]
    J2n=[]
    eJp=[];eJn=[];eJ1p=[];eJ1n=[];eJ2p=[];eJ2n=[]
    num=cs.s2n(Ls,'a',m,n,j,l)
    for j in Jp:
        eJp+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J1p:
        eJ1p+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J2p:
        eJ2p+=[(num,cs.s2n(Ls,*j))] if (tuple(cs. s2c(Ls,*j)) in siteSet) else []
    return eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n,[(num,num)],[]

def b_linked_to(Ls,m,n,j,l):
    siteSet=cs.site_gen(Ls)
    Jp=[['c',m,n,j+1,l+1],['c',m,n,j,l],['c',m,n,j+1,l]]
    Jn=[['d',m+1,n+1,j,l],['d',m,n,j,l],['d',m+1,n,j,l]]
    J1p=[['b',m+1,n+1,j+1,l+1],['b',m-1,n-1,j-1,l-1]]
    J1n=[]
    J2p=[['b',m+1,n+1,j-1,l-1],['b',m-1,n-1,j+1,l+1]]
    J2n=[]
    eJp=[];eJn=[];eJ1p=[];eJ1n=[];eJ2p=[];eJ2n=[]
    num=cs.s2n(Ls,'b',m,n,j,l)
    for j in Jp:
        eJp+=[(num,cs.s2n(Ls,*j))] if (tuple(cs. s2c(Ls,*j)) in siteSet) else []
    for j in Jn:
        eJn+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J1p:
        eJ1p+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J2p:
        eJ2p+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    return eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n,[(num,num)],[]

def c_linked_to(Ls,m,n,j,l):
    siteSet=cs.site_gen(Ls)
    Jp=[['a',m+1,n+1,j,l],['b',m,n,j,l],['b',m,n,j-1,l],['a',m,n,j,l],['a',m+1,n,j,l],['b',m,n,j-1,l-1]]
    Jn=[]
    J1n=[['c',m+1,n+1,j+1,l+1],['c',m-1,n-1,j-1,l-1]]
    J1p=[]
    J2n=[['c',m+1,n+1,j-1,l-1],['c',m-1,n-1,j+1,l+1]]
    J2p=[]
    eJp=[];eJn=[];eJ1p=[];eJ1n=[];eJ2p=[];eJ2n=[]
    num=cs.s2n(Ls,'c',m,n,j,l)
    for j in Jp:
        eJp+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J1n:
        eJ1n+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J2n:
        eJ2n+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    return eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n,[],[(num,num)]

def d_linked_to(Ls,m,n,j,l):
    siteSet=cs.site_gen(Ls)
    Jp=[['a',m,n,j+1,l+1],['a',m,n,j,l],['a',m,n,j+1,l]]
    Jn=[['b',m,n,j,l],['b',m-1,n,j,l],['b',m-1,n-1,j,l]]
    J1n=[['d',m+1,n+1,j+1,l+1],['d',m-1,n-1,j-1,l-1]]
    J1p=[]
    J2n=[['d',m+1,n+1,j-1,l-1],['d',m-1,n-1,j+1,l+1]]
    J2p=[]
    eJp=[];eJn=[];eJ1p=[];eJ1n=[];eJ2p=[];eJ2n=[]
    num=cs.s2n(Ls,'d',m,n,j,l)
    for j in Jp:
        eJp+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in Jn:
        eJn+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J1n:
        eJ1n+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J2n:
        eJ2n+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    return eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n,[],[(num,num)]

def linkBack(links,eL):
    links_=[]
    for link in links:
        n1,n2=link
        c1x,c1y,c1z,c1w=cs.n2c(eL,n1)
        c2x,c2y,c2z,c2w=cs.n2c(eL,n2)

        c1x=c1x if c1x<Lx else (c1x-Lx)
        c1y=c1y if c1y<Ly else (c1y-Ly)
        c1z=c1z if c1z<Lz else (c1z-Lz)
        c1w=c1w if c1w<Lw else (c1w-Lw)
        coor1=array([c1x,c1y,c1z,c1w])
        
        c2x=c2x if c2x<Lx else (c2x-Lx)
        c2y=c2y if c2y<Ly else (c2y-Ly)
        c2z=c2z if c2z<Lz else (c2z-Lz)
        c2w=c2w if c2w<Lw else (c2w-Lw)
        coor2=array([c2x,c2y,c2z,c2w])
        
        n1=cs.c2n(Ls,coor1)
        n2=cs.c2n(Ls,coor2)
        link=(n1,n2)
        links_+=[link]
    return links_  

def edge_gen(axis):
    edgeJp=[]
    edgeJn=[]
    edgeJ1p=[]
    edgeJ1n=[]
    edgeJ2p=[]
    edgeJ2n=[]
    mPos=[]
    mNeg=[]
    extend={'x':[2,0,0,0],'y':[0,2,0,0],'z':[0,0,2,0],'w':[0,0,0,2],'none':[0,0,0,0]}
    eL=array(Ls)
    for a in axis:
        eL+=array(extend[a])
    ex,ey,ez,ew=eL
    eN=ex*ey*ez*ew
    for siteNum in range(eN):
        coor=cs.n2c(eL,siteNum)
        sublat,m,n,j,l=cs.c2s(eL,coor)
        linkedTo={'a': a_linked_to,'b': b_linked_to,'c': c_linked_to,'d': d_linked_to}
        eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n,Mp,Mn=linkedTo.get(sublat)(eL,m,n,j,l)
        edgeJp+=eJp; edgeJn+=eJn
        edgeJ1p+=eJ1p; edgeJ1n+=eJ1n
        edgeJ2p+=eJ2p; edgeJ2n+=eJ2n
        mPos+=Mp; mNeg+=Mn
    couplingTerms=[set(linkBack(edgeJp,eL)),set(linkBack(edgeJn,eL)),set(linkBack(edgeJ1p,eL)),set(linkBack(edgeJ1n,eL)),set(linkBack(edgeJ2p,eL)),set(linkBack(edgeJ2n,eL)),set(linkBack(mPos,eL)),set(linkBack(mNeg,eL)),Ls]
    return couplingTerms

    
def hami_gen(Jp,Jn,J1p,J1n,J2p,J2n,Mp):
    
    hami=sp.dok_matrix((N, N), dtype=numpy.float64)
    coupSet={0:setJp,1:setJn,2:setJ1p,3:setJ1n,4:setJ2p,5:setJ2n,6:setMp,7:setMn}
    coupVal={0:Jp,1:Jn,2:J1p,3:J1n,4:J2p,5:J2n,6:Mp,7:-Mp}
    for i in range(8):
        J=coupVal[i]
        pairs=coupSet[i]
        for pair in pairs:
            nx,ny=pair
            hami[nx,ny]=J                
    return hami

def Mp_phase_diagram(Jp,Jn,J1p,J1n,J2p,J2n):
    Mps=linspace(-10,10,201)
##    Mps=[0,1,2,3,4,5,6,7,8,9]
##    Mps=[6]
    X=[];Y=[];ASI=[]
    nB=[];nS=[];Ne=N/2
    for i in range(N):
        x,y,z,w=cs.n2c(Ls,i)
        if (x in [0,1]) or (x in [Lx-1,Lx-2]) or (z in [0,1]) or (z in [Lz-1,Lz-2]):
            nS+=[i]
        else:
            nB+=[i]
    for i in range(len(Mps)):
        print(i,Mps[i])
        hami=hami_gen(Jp,Jn,J1p,J1n,J2p,J2n,Mps[i])
        hami=hami.toarray()
        hami=cupy.array(hami)
        try:
            vals,vecs=cupy.linalg.eigh(hami,UPLO='L')
        except:
            print('error!', Mps[i],i)
            continue
        iB=sum(abs(vecs[nB,:]),axis=0)
        iS=sum(abs(vecs[nS,:]),axis=0)
        asi=iS[Ne-1:Ne+1]/iB[Ne-1:Ne+1]/len(nS)*(len(nB))
        asi=cupy.asnumpy(asi)
        asi=log(asi.astype('float64'))
        vals=vals[Ne-1:Ne+1]
        Y+=[vals]
        X+=[Mps[i]*ones(len(vals))]
        ASI+=[asi]
    PD=(X,Y,ASI)
    numpy.save('PD_%d%d%d%d.npy'%(Lx,Ly,Lz,Lw),PD)

def plotter(Lx,Ly,Lz,Lw):
    x,y,color=numpy.load('PD_%d%d%d%d.npy'%(Lx,Ly,Lz,Lw),allow_pickle=True)
    cm=plt.cm.get_cmap('RdYlBu_r')
##    print(x,y)
    sc=plt.scatter(x,y,s=10,c=color,vmin=-2,vmax=2,cmap=cm)
##    plt.plot(x,y)
    plt.xlim([-10,10])
    plt.ylim([-2,2])
    plt.xlabel("m")
    plt.ylabel("E")
    if Lx==50:
        cbar=plt.colorbar(sc)
        cbar.ax.set_ylabel(r'$\ln{[\overline{|\psi(x_s)|}/\overline{|\psi(x_b)|}]}$',rotation=270)
##      plt.title("$J=%.f;J'=%.f;J''=%.f$"%(Jp,J1p/2,J2p/2))
##    plt.savefig("finitePD_%d%d%d%d.svg"%(Lx,Ly,Lz,Lw))
##    plt.savefig("finitePD.png")
##    plt.show()

Nk=1000
Kx=linspace(-pi,pi,Nk)
Ky=linspace(-pi,pi,Nk)
Kz=linspace(-pi,pi,Nk)
Kw=linspace(-pi,pi,Nk)

def energy(J,J1,J2,m,k):
    kx,ky,kz,kw=k
    d1=J*(2*cos(kx)+cos(ky))
    d2=J*sin(ky)
    d3=J*(2*cos(kz)+cos(kw))
    d4=J*sin(kw)
    d5=m+2*J1*cos(2*kx+2*kz)+2*J2*cos(2*kx-2*kz)
    return (d1**2+d2**2+d3**2+d4**2+d5**2)**0.5

def infinite_bandedge(J,J1,J2):
    M=linspace(-10,10,161)
    E=[];Em=[]
    for m in M:
        X,Z=meshgrid(Kx,Kz)
        Emin=energy(J,J1,J2,m,[X,0,Z,0]).min()
##        print(Emin)
        E+=[Emin]
        Em+=[-Emin]
    plt.plot(M,E,c="black")
    plt.plot(M,Em,c="black")
    plt.ylim([-2,2])
##    plt.show()

Jp=1; Jn=-Jp
J1p=2.*Jp; J1n=-J1p
J2p=-2.*Jp; J2n=-J2p

##setJp,setJn,setJ1p,setJ1n,setJ2p,setJ2n,setMp,setMn,Ls=edge_gen(['y','w'])
##Mp_phase_diagram(Jp,Jn,J1p,J1n,J2p,J2n)
##plotter(Lx,Ly,Lz,Lw)
plotter(6,2,6,2)
plotter(8,2,8,2)
plotter(10,2,10,2)
plotter(14,2,14,2)
plotter(20,2,20,2)
##plotter(30,2,30,2)
plotter(50,2,50,2)

infinite_bandedge(Jp,J1p,J2p)
plt.savefig("FiniteSizeEffect.svg")
plt.show()
