import numpy
from scipy import *
import subprocess
import matplotlib.pyplot as plt
from pylab import *

dpath="../data_exp/"
def bulk_edge_plotter(m,dataType):
    freq=linspace(80,160,81)
##    edgeSites=['g5041']

    edgeSites=['g1021', 'g1011', 'g1031', 'g1041', 'g1051', 'g1061','g2011', 'g2021', 'g2031', 'g2041', 'g2051', 'g2061', 'g3011','g3021', 'g3051', 'g3061', 'g4011', 'g4021', 'g4051', 'g4061', 'g5011', 'g5021', 'g5031','g5041', 'g5051', 'g5061', 'g6011', 'g6021', 'g6031', 'g6041','g6051', 'g6061']
    bulkSites=['g3031','g3041','g4031','g4041']
    edge_imp=zeros(len(freq))*1j
    bulk_imp=zeros(len(freq))*1j
    for edge in edgeSites:
        edge_imp+=abs(real(numpy.load(dpath+'m%d'%m+edge+dataType+'.npy')))
    for bulk in bulkSites:
        bulk_imp+=abs(real(numpy.load(dpath+'m%d'%m+bulk+dataType+'.npy')))
    plt.plot(freq,abs(edge_imp)/32,'red')
    plt.plot(freq,abs(bulk_imp)/4,'--')
    if m==0:
        plt.legend(["Averaged edge sites LDOS","Averaged bulk sites LDOS"])
    plt.xlim([80,160])
    plt.xticks([80,100,113,120,140,160])
    if not m==0:
        plt.yticks([])
    plt.xlabel("f/kHz")
##    plt.plot(freq,abs(bulk_imp)/4*36/(abs(edge_imp)+abs(bulk_imp)))
    plt.title("m=%d"%m,y=0.9)
    plt.ylim([0,800])
##    plt.savefig('../fig3a_m%d.svg'%m)

##    plt.show()


def m_ASI(m):
    freq=linspace(80,160,81)
    edgeSites=['g1021', 'g1011', 'g1031', 'g1041', 'g1051', 'g1061','g2011', 'g2021', 'g2031', 'g2041', 'g2051', 'g2061', 'g3011','g3021', 'g3051', 'g3061', 'g4011', 'g4021', 'g4051', 'g4061', 'g5011', 'g5021', 'g5031','g5041', 'g5051', 'g5061', 'g6011', 'g6021', 'g6031', 'g6041','g6051', 'g6061']
    bulkSites=['g3031','g3041','g4031','g4041']
    edge_imp=zeros(len(freq))
    bulk_imp=zeros(len(freq))
    for edge in edgeSites:
        edge_imp+=abs(real(numpy.load(dpath+'m%d'%m+edge+'imp_f'+'.npy')))
    for bulk in bulkSites:
        bulk_imp+=abs(real(numpy.load(dpath+'m%d'%m+bulk+'imp_f'+'.npy')))
        
    impB=bulk_imp[freq==120];impS=edge_imp[freq==120]
    ASI=(impS)/(impB)/len(edgeSites)*(len(bulkSites))
    return ASI
            
def plot_ASI():
    mass=[0,1,2,3,4,5,6,7,8]
##    mass=[0,1,3,4,8]
    ASI=[]
    for m in mass:
        ASI+=[m_ASI(m)]
        
    plt.plot(mass,ASI)
    plt.scatter(mass,ASI)
    plt.xlabel('m')
    plt.ylabel(r'$\frac{Re[\overline{Z^{s}}]}{Re[\overline{Z^{b}}]}$',rotation=0)
    plt.xlim([0,8])
    plt.ylim([0,7])
    plt.yticks([0,1,2,3,4,5,6],[0,1,2,3,4,5,6])
##    plt.yticks([0,1,2,3,4,5],[0,1,2,'',4,''])
    plt.legend(["Ratio of surface to bulk averaged LDOS"])
    plt.plot([0,8],[1,1],'--')
    

##    plt.title("E=0")
    plt.savefig("../fig3b.svg")
    plt.show()

####fig2d
##m=1
##plt.rcParams.update({'font.size': 15})
##bulk_edge_plotter(m,'imp_f')
##plt.show()
##plt.savefig('../fig3a_m%d.svg'%m)
##fig3
plt.rcParams.update({'font.size': 15})
plot_ASI()
    
####figS2
##plt.figure(figsize=[13,12])
##for m in [0,1,2,3,4,5,6,7,8]:
##    print(m)
##    plt.subplot(3,3,m+1)
##    bulk_edge_plotter(m,'imp_f')
##plt.savefig("../figS2.svg")
##plt.show()
##    
        
        
