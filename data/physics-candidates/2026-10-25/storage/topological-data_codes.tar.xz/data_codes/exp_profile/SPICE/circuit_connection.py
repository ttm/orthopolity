from scipy import *
import commonFuncs as cs
import numpy
Lx,Ly,Lz,Lw=6,2,6,2
N=Lx*Ly*Lz*Lw
Ls=[Lx,Ly,Lz,Lw]
siteSet=cs.site_gen(Ls)


def a_linked_to(Ls,m,n,j,l):
    siteSet=cs.site_gen(Ls)
    Jp=[['c',m,n,j,l],['c',m-1,n,j,l],['d',m,n,j,l],['d',m,n,j-1,l],['c',m-1,n-1,j,l],['d',m,n,j-1,l-1]]
    Jn=[]
    J1p=[['a',m+1,n+1,j+1,l+1],['a',m-1,n-1,j-1,l-1]]
    J1n=[]
    J2p=[['a',m+1,n+1,j-1,l-1],['a',m-1,n-1,j+1,l+1]]
    J2n=[]
    eJp=[];eJn=[];eJ1p=[];eJ1n=[];eJ2p=[];eJ2n=[]
    num=cs.s2n(Ls,'a',m,n,j,l)
    for j in Jp:
        eJp+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J1p:
        eJ1p+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J2p:
        eJ2p+=[(num,cs.s2n(Ls,*j))] if (tuple(cs. s2c(Ls,*j)) in siteSet) else []
    return eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n,[(num,-1)],[],[],[]

def b_linked_to(Ls,m,n,j,l):
    siteSet=cs.site_gen(Ls)
    Jp=[['c',m,n,j+1,l+1],['c',m,n,j,l],['c',m,n,j+1,l]]
    Jn=[['d',m+1,n+1,j,l],['d',m,n,j,l],['d',m+1,n,j,l]]
    J1p=[['b',m+1,n+1,j+1,l+1],['b',m-1,n-1,j-1,l-1]]
    J1n=[]
    J2p=[['b',m+1,n+1,j-1,l-1],['b',m-1,n-1,j+1,l+1]]
    J2n=[]
    eJp=[];eJn=[];eJ1p=[];eJ1n=[];eJ2p=[];eJ2n=[]
    num=cs.s2n(Ls,'b',m,n,j,l)
    for j in Jp:
        eJp+=[(num,cs.s2n(Ls,*j))] if (tuple(cs. s2c(Ls,*j)) in siteSet) else []
    for j in Jn:
        eJn+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J1p:
        eJ1p+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J2p:
        eJ2p+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    return eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n,[],[(num,-1)],[],[]

def c_linked_to(Ls,m,n,j,l):
    siteSet=cs.site_gen(Ls)
    Jp=[['a',m+1,n+1,j,l],['b',m,n,j,l],['b',m,n,j-1,l],['a',m,n,j,l],['a',m+1,n,j,l],['b',m,n,j-1,l-1]]
    Jn=[]
    J1n=[['c',m+1,n+1,j+1,l+1],['c',m-1,n-1,j-1,l-1]]
    J1p=[]
    J2n=[['c',m+1,n+1,j-1,l-1],['c',m-1,n-1,j+1,l+1]]
    J2p=[]
    eJp=[];eJn=[];eJ1p=[];eJ1n=[];eJ2p=[];eJ2n=[]
    num=cs.s2n(Ls,'c',m,n,j,l)
    for j in Jp:
        eJp+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J1n:
        eJ1n+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J2n:
        eJ2n+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    return eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n,[],[],[(num,-1)],[]

def d_linked_to(Ls,m,n,j,l):
    siteSet=cs.site_gen(Ls)
    Jp=[['a',m,n,j+1,l+1],['a',m,n,j,l],['a',m,n,j+1,l]]
    Jn=[['b',m,n,j,l],['b',m-1,n,j,l],['b',m-1,n-1,j,l]]
    J1n=[['d',m+1,n+1,j+1,l+1],['d',m-1,n-1,j-1,l-1]]
    J1p=[]
    J2n=[['d',m+1,n+1,j-1,l-1],['d',m-1,n-1,j+1,l+1]]
    J2p=[]
    eJp=[];eJn=[];eJ1p=[];eJ1n=[];eJ2p=[];eJ2n=[]
    num=cs.s2n(Ls,'d',m,n,j,l)
    for j in Jp:
        eJp+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in Jn:
        eJn+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J1n:
        eJ1n+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    for j in J2n:
        eJ2n+=[(num,cs.s2n(Ls,*j))] if (tuple(cs.s2c(Ls,*j)) in siteSet) else []
    return eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n,[],[],[],[(num,-1)]

def linkBack(links,eL):
    links_=[]
    for link in links:
        n1,n2=link
        c1x,c1y,c1z,c1w=cs.n2c(eL,n1)
        c2x,c2y,c2z,c2w=cs.n2c(eL,n2)

        c1x=c1x if c1x<Lx else (c1x-Lx)
        c1y=c1y if c1y<Ly else (c1y-Ly)
        c1z=c1z if c1z<Lz else (c1z-Lz)
        c1w=c1w if c1w<Lw else (c1w-Lw)
        coor1=array([c1x,c1y,c1z,c1w])
        
        c2x=c2x if c2x<Lx else (c2x-Lx)
        c2y=c2y if c2y<Ly else (c2y-Ly)
        c2z=c2z if c2z<Lz else (c2z-Lz)
        c2w=c2w if c2w<Lw else (c2w-Lw)
        coor2=array([c2x,c2y,c2z,c2w])
        
        n1=cs.c2n(Ls,coor1)
        n2=cs.c2n(Ls,coor2)
        link=(n1,n2)
        links_+=[link]
    return links_  

def count_pairs(links):
    counter=zeros(N)
    for link in links:
        n1,n2=link
        counter[n1]+=1
        counter[n2]+=1
    return counter
        

def edge_gen(axis):
    edgeJp=[]
    edgeJn=[]
    edgeJ1p=[]
    edgeJ1n=[]
    edgeJ2p=[]
    edgeJ2n=[]
    ga=[]
    gb=[]
    gc=[]
    gd=[]
    extend={'x':[2,0,0,0],'y':[0,2,0,0],'z':[0,0,2,0],'w':[0,0,0,2],'none':[0,0,0,0]}
    eL=array(Ls)
    for a in axis:
        eL+=array(extend[a])
    ex,ey,ez,ew=eL
    eN=ex*ey*ez*ew
    for siteNum in range(eN):
        coor=cs.n2c(eL,siteNum)
        sublat,m,n,j,l=cs.c2s(eL,coor)
        linkedTo={'a': a_linked_to,'b': b_linked_to,'c': c_linked_to,'d': d_linked_to}
        eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n,Ga,Gb,Gc,Gd=linkedTo.get(sublat)(eL,m,n,j,l)
        edgeJp+=eJp; edgeJn+=eJn
        edgeJ1p+=eJ1p; edgeJ1n+=eJ1n
        edgeJ2p+=eJ2p; edgeJ2n+=eJ2n
        ga+=Ga; gb+=Gb; gc+=Gc; gd+=Gd
    eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n=set(linkBack(edgeJp,eL)),set(linkBack(edgeJn,eL)),set(linkBack(edgeJ1p,eL)),set(linkBack(edgeJ1n,eL)),set(linkBack(edgeJ2p,eL)),set(linkBack(edgeJ2n,eL))
    edic={0:eJp,1:eJn,2:eJ1p,3:eJ1n,4:eJ2p,5:eJ2n}
    coupNum=zeros([N,6])
    for i in range(6):
        coupNum[:,i]=count_pairs(edic[i])/2
##    print(coupNum)
    couplingTerms=[eJp,eJn,eJ1p,eJ1n,eJ2p,eJ2n,set(linkBack(ga,eL)),set(linkBack(gb,eL)),set(linkBack(gc,eL)),set(linkBack(gd,eL)),coupNum,Ls]
    numpy.save('coupling_terms.npy',couplingTerms)

if __name__=='__main__':
    edge_gen(['y','w'])


