import numpy
from scipy import *
import subprocess
import matplotlib.pyplot as plt
import SPICE.commonFuncs as cs
from pylab import *
from mpl_toolkits.mplot3d import Axes3D

setJp,setJn,setJ1p,setJ1n,setJ2p,setJ2n,setGa,setGb,setGc,setGd,coupNum,Ls=numpy.load('./SPICE/coupling_terms.npy',allow_pickle=True)
Lx,Ly,Lz,Lw=Ls
N=Lx*Ly*Lz*Lw
dpath="../data_exp/"

def wave_plot(m):
    X=[];Y=[];Z=[];W=[];dens=[]
    wave=numpy.load('m%d'%m+'wave_data.npy')
    for siteNum in range(N):
        coor=cs.n2c(Ls,siteNum)
        X+=[coor[0]];Y+=[coor[1]];Z+=[coor[2]];W+=[coor[3]]
        dens+=[real(wave[siteNum])]
    X=array(X);Y=array(Y);Z=array(Z);W=array(W);dens=array(dens)
    plt.figure(figsize=(15,15))
    plt.title("m=%d"%m)
    cm=plt.cm.get_cmap('gist_heat_r')
    for y in [0,1]:
        for w in [0,1]:
            plt.subplot(2,2,y*2+w+1)
            x=X[(W==w)*(Y==y)]
            z=Z[(W==w)*(Y==y)]
            dens_=dens[(W==w)*(Y==y)]
            sc=plt.scatter(x,z,s=dens_*scale,c=dens_/600.0,vmin=0,vmax=1,cmap=cm)
            plt.xlabel("x")
            plt.ylabel("z")
            plt.axis('off')
            plt.xlim([-0.5,5.4])
            plt.ylim([-0.5,5.4])
##            cbar=plt.colorbar(sc)

    plt.savefig('../fig2_m%d.svg'%(m))
##    plt.show()
            

def visual_data(m,dataName):
    name='g'
    wave=zeros(N)*1j
    shiftDic={'00':0,'10':6,'11':78,'01':72}
    for boardNO in ['00','10','11','01']: 
        data=numpy.load(dpath+'m%d'%m+name+boardNO+dataName+'.npy')
        data=abs(data)
        list6=list(array([1,2,3,4,5,6])+shiftDic[boardNO])
        site=list6+list(array(list6)+12)+list(array(list6)+24)+list(array(list6)+36)+list(array(list6)+48)+list(array(list6)+60)
        for i in range(len(site)):
            wave[site[i]-1]=data[i]
    numpy.save('m%d'%m+'wave_data.npy',wave)

scale=4
for m in [0,4,8]:
    visual_data(m,'imp')
    plt.rcParams.update({'font.size': 24})
    wave_plot(m)

