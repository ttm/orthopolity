function fon = figuresize2_2rows2cols(x,y,h,units)

if (nargin<4)
    units='points';
end
if (nargin<3)
    h = gcf;
end
if (nargin<1)
    x = 246;
    y = 246/1.61803*2;
end

set(h,'units',units,'paperunits',units)
pos=get(h,'position');
set(h,'position',[pos(1) pos(2) x y],'papersize',[x y],'paperposition',[0 0 x y])

set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
% fon = 9;
fon = 12;