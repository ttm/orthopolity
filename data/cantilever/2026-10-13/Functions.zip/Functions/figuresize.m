function fon = figuresize(x,y,h,units)

if (nargin<4)
    units='centimeters';
end
if (nargin<3)
    h=gcf;
end
if (nargin<2)
    x = 16;
    y = x/1.61803;
end
if (nargin<1)
    x = 16;
end

set(h,'units',units,'paperunits',units)
pos=get(h,'position');
set(h,'position',[pos(1) pos(2) x y],'papersize',[x y],'paperposition',[0 0 x y])

set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
fon = 11;

