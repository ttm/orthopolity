function titlelatex(text,fon)

title(text,'Interpreter', 'Latex','FontSize',fon)
