function legendlatex(fon,loc,siz,ncol)
if(~exist('ncol','var') || nargin<4 )
    ncol = 1;
end
if(~exist('siz','var') || nargin<3 )
    siz = 6;
end
if(nargin<2)
    loc = 'northwest';
end

leg = legend('Interpreter','Latex','fontsize',fon,'Location',loc,'NumColumns',ncol);
leg.ItemTokenSize = [siz,6];
