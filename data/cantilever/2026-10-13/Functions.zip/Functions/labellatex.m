function labellatex(textx,texty,fon)
if(~strcmp('',textx))
    xlabel(textx,'Interpreter', 'Latex','FontSize',fon);
end
if(~strcmp('',texty))
    ylabel(texty,'Interpreter', 'Latex','FontSize',fon);
end
set(gca,'Fontsize',fon);